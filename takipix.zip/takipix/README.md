# Takipix

Instagram takipçi analizi ve otomasyon uygulaması (Flutter).

## APK nasıl alınır (GitHub)

1. GitHub'da yeni bir repo aç, bu klasörün **içindekileri** (zip'i açıp) repoya yükle.
   `.github/workflows/build-apk.yml` dosyası da yüklenmiş olmalı.
2. `main` branch'e push edince **Actions → Build APK** otomatik çalışır
   (elle de çalıştırabilirsin: Actions → Build APK → Run workflow).
3. İş bitince çalışma sayfasının altındaki **Artifacts → takipix-apk** dosyasını indir,
   içinden `app-release.apk` çıkar.

Android klasörü ve uygulama ikonu workflow içinde otomatik üretilir.
Logo kaynakları: `assets/icon/`.

## Özellikler

| Ekran | İçerik |
|---|---|
| Giriş | "Instagram ile bağlan" / kullanıcı adı ile devam |
| Panel | Takipçi/takip/karşılıklı sayıları, bugün kazanılan-kaybedilen, günlük limit (150), en çok izlenen video + silme, tüm gönderiler |
| Takip | Geri takip etmeyenler, hayranlar, karşılıklı; toplu seçip takipten çıkarma (aralıklı) |
| Etkileşim | En çok beğenen/yorum yapan sıralaması, "beğenenleri beğen" (kişi kaç gönderi beğendiyse o kadar, aralıklı) |
| Mesaj | Anahtar kelime → otomatik cevap kuralları, deneme alanı, cevap günlüğü |
| Premium | Özellik tablosu, plan seçimi, PRO rozeti, reklamsız kullanım |

### Premium'a özel
Beğenenleri beğen, otomatik mesaj yanıt, tam etkileşim listesi, reklamsız, PRO rozeti, kredisiz takipten çıkarma.

### Reklam / kredi yerleşimi
- Uygulama açılışında 1 tam ekran reklam
- Her 2. toplu işlemden sonra tam ekran reklam
- Alt banner alanı
- Ödüllü reklam: izle → +3 kredi (5 takipten çıkarma = 1 kredi)
- Günlük hediye: +2 kredi

Ayarlar `lib/state/app_state.dart` başında: `dailyLimit`, `jobGap`, `unfollowsPerCredit`, `rewardCredits`, `plans`.

## Önemli: Instagram verisi ve reklam/ödeme

- **Instagram'ın resmi API'si** takipçi listesi okuma, takipten çıkarma, otomatik beğeni
  gibi işlemlere izin vermez. Bu yüzden uygulama şu an **demo veriyle** çalışır
  (`lib/services/instagram_service.dart` → `DemoInstagramService`). Arayüz ve tüm akışlar
  çalışır; gerçek servise geçmek için aynı arayüzü (`InstagramService`) uygulayan bir sınıf yazıp
  `lib/main.dart` içinde değiştirmen yeterli.
- Şifreyle giriş + gayriresmi çağrılar hesap banı riski taşır ve Google Play politikalarına aykırıdır.
- **Reklamlar** simülasyondur: `lib/services/ad_service.dart` içine `google_mobile_ads` (AdMob) bağlanır.
- **Premium satın alma** simülasyondur: `activatePremium` metodunu `in_app_purchase` başarılı olunca çağır.
- Aralıklar `jobGap` ile demo için kısa (0,9 sn). Gerçek kullanımda 20-60 sn rastgele aralık kullan.

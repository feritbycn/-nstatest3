import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'screens/home_shell.dart';
import 'screens/login_screen.dart';
import 'services/instagram_service.dart';
import 'state/app_state.dart';
import 'theme.dart';
import 'widgets/common.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  // Önce hemen bir şey çiz, ağır işleri sonra yap.
  runApp(const _Boot());
}

class _Boot extends StatefulWidget {
  const _Boot();

  @override
  State<_Boot> createState() => _BootState();
}

class _BootState extends State<_Boot> {
  AppState? _state;
  String? _error;

  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    try {
      final prefs = await SharedPreferences.getInstance()
          .timeout(const Duration(seconds: 8));
      final state = AppState(prefs, DemoInstagramService());
      await state.restore().timeout(const Duration(seconds: 8));
      if (mounted) setState(() => _state = state);
    } catch (e, st) {
      if (mounted) setState(() => _error = '$e\n\n$st');
    }
  }

  @override
  Widget build(BuildContext context) {
    final state = _state;
    if (state != null) return TakipixApp(state: state);

    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: buildTheme(),
      home: Scaffold(
        body: Center(
          child: _error != null
              ? SingleChildScrollView(
                  padding: const EdgeInsets.all(24),
                  child: SelectableText(
                    'Başlatma hatası:\n\n$_error',
                    style: const TextStyle(fontSize: 12),
                  ),
                )
              : const Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    LogoMark(size: 84),
                    SizedBox(height: 24),
                    CircularProgressIndicator(color: AppColors.pink),
                  ],
                ),
        ),
      ),
    );
  }
}

class TakipixApp extends StatelessWidget {
  const TakipixApp({super.key, required this.state});
  final AppState state;

  @override
  Widget build(BuildContext context) {
    return AppScope(
      state: state,
      child: MaterialApp(
        title: 'Takipix',
        debugShowCheckedModeBanner: false,
        theme: buildTheme(),
        home: const _Root(),
      ),
    );
  }
}

class _Root extends StatelessWidget {
  const _Root();

  @override
  Widget build(BuildContext context) {
    final app = AppScope.of(context);
    return AnimatedSwitcher(
      duration: const Duration(milliseconds: 350),
      child: app.loggedIn
          ? const HomeShell(key: ValueKey('home'))
          : const LoginScreen(key: ValueKey('login')),
    );
  }
}

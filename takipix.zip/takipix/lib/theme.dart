import 'package:flutter/material.dart';

class AppColors {
  static const bg = Color(0xFF0B0B12);
  static const surface = Color(0xFF15151F);
  static const surface2 = Color(0xFF1F1F2E);
  static const purple = Color(0xFF7C3AED);
  static const pink = Color(0xFFEC4899);
  static const orange = Color(0xFFF59E0B);
  static const gold = Color(0xFFFFC857);
  static const green = Color(0xFF22C55E);
  static const red = Color(0xFFEF4444);
  static const textDim = Color(0xFF9CA3AF);

  static const gradient = LinearGradient(
    colors: [purple, pink, orange],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
  static const goldGradient = LinearGradient(
    colors: [Color(0xFFFFE08A), Color(0xFFF5A623)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
}

ThemeData buildTheme() {
  final base = ThemeData(
    useMaterial3: true,
    brightness: Brightness.dark,
    colorScheme: const ColorScheme.dark(
      primary: AppColors.pink,
      secondary: AppColors.purple,
      surface: AppColors.surface,
    ),
    scaffoldBackgroundColor: AppColors.bg,
  );
  return base.copyWith(
    appBarTheme: const AppBarTheme(
      backgroundColor: Colors.transparent,
      elevation: 0,
      scrolledUnderElevation: 0,
    ),
    navigationBarTheme: NavigationBarThemeData(
      backgroundColor: AppColors.surface,
      indicatorColor: AppColors.pink.withOpacity(0.22),
      labelTextStyle: WidgetStateProperty.all(
        const TextStyle(fontSize: 11, fontWeight: FontWeight.w600),
      ),
    ),
    snackBarTheme: const SnackBarThemeData(
      behavior: SnackBarBehavior.floating,
    ),
  );
}

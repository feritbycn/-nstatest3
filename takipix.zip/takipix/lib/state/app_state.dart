import 'dart:convert';
import 'dart:math';

import 'package:flutter/widgets.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../models.dart';
import '../services/instagram_service.dart';

/// Çalışan toplu işlem (takipten çıkarma, otomatik beğeni vb.)
class JobInfo {
  JobInfo(this.label, this.total);
  final String label;
  final int total;
  int done = 0;
  bool cancelled = false;
}

class AppScope extends InheritedNotifier<AppState> {
  const AppScope({super.key, required AppState state, required super.child})
      : super(notifier: state);

  static AppState of(BuildContext context) =>
      context.dependOnInheritedWidgetOfExactType<AppScope>()!.notifier!;
}

class AppState extends ChangeNotifier {
  AppState(this.prefs, this.service);

  final SharedPreferences prefs;
  final InstagramService service;

  // ---- Ayarlar ----------------------------------------------------------
  /// Günlük işlem limiti (takipten çıkarma + beğeni + silme).
  static const dailyLimit = 150;

  /// İşlemler arası bekleme. Demo için kısa; gerçek servis bağlarken
  /// 20-60 sn rastgele aralık kullanın (hesap güvenliği için).
  static const jobGap = Duration(milliseconds: 900);

  /// Ücretsiz kullanıcı: kaç takipten çıkarma 1 krediye mal olur.
  static const unfollowsPerCredit = 5;

  /// Reklam izleyince kazanılan kredi.
  static const rewardCredits = 3;

  static const plans = [
    PremiumPlan(id: 'week', title: 'Haftalık', price: '₺49,99', days: 7),
    PremiumPlan(
        id: 'month',
        title: 'Aylık',
        price: '₺129,99',
        days: 30,
        tag: 'POPÜLER'),
    PremiumPlan(
        id: 'year',
        title: 'Yıllık',
        price: '₺799,99',
        days: 365,
        tag: '%50 İNDİRİM'),
  ];

  // ---- Durum -------------------------------------------------------------
  bool ready = false;
  bool loggedIn = false;
  bool loading = false;
  IgAccount? account;

  List<IgUser> users = [];
  List<IgPost> posts = [];
  List<Engager> engagers = [];
  DailyChange? change;

  int tab = 0;
  int credits = 6;
  DateTime? premiumUntil;
  int actionsToday = 0;
  String _actionsDate = '';
  String _bonusDate = '';
  int jobsCompleted = 0;

  JobInfo? job;
  final Set<String> likedBack = {};

  // Otomatik yanıt
  bool autoReplyOn = false;
  List<AutoReplyRule> rules = [];
  final List<ReplyLogEntry> replyLog = [];

  // ---- Türetilmiş --------------------------------------------------------
  bool get isPremium =>
      premiumUntil != null && premiumUntil!.isAfter(DateTime.now());
  List<IgUser> get following => users.where((u) => u.iFollow).toList();
  List<IgUser> get followers => users.where((u) => u.followsMe).toList();
  List<IgUser> get notFollowingBack =>
      users.where((u) => u.iFollow && !u.followsMe).toList();
  List<IgUser> get fans =>
      users.where((u) => u.followsMe && !u.iFollow).toList();
  List<IgUser> get mutual =>
      users.where((u) => u.followsMe && u.iFollow).toList();
  int get remainingActions => max(0, dailyLimit - actionsToday);

  IgPost? get topVideo {
    final v = posts.where((p) => p.isVideo).toList();
    if (v.isEmpty) return null;
    v.sort((a, b) => b.views.compareTo(a.views));
    return v.first;
  }

  bool get canClaimBonus => _bonusDate != _today();

  String _today() {
    final n = DateTime.now();
    return '${n.year}-${n.month}-${n.day}';
  }

  void _rollDay() {
    if (_actionsDate != _today()) {
      _actionsDate = _today();
      actionsToday = 0;
    }
  }

  // ---- Başlatma ----------------------------------------------------------
  Future<void> restore() async {
    credits = prefs.getInt('credits') ?? 6;
    final until = prefs.getInt('premiumUntil');
    if (until != null) premiumUntil = DateTime.fromMillisecondsSinceEpoch(until);
    _actionsDate = prefs.getString('actionsDate') ?? '';
    actionsToday = prefs.getInt('actionsToday') ?? 0;
    _bonusDate = prefs.getString('bonusDate') ?? '';
    autoReplyOn = prefs.getBool('autoReplyOn') ?? false;
    final raw = prefs.getString('rules');
    if (raw != null) {
      rules = (jsonDecode(raw) as List)
          .map((e) => AutoReplyRule.fromJson(e as Map<String, dynamic>))
          .toList();
    } else {
      rules = [
        AutoReplyRule(
            id: 'r1',
            keyword: 'fiyat',
            reply: 'Merhaba! 🙌 Fiyat listesini hemen DM olarak iletiyorum.'),
        AutoReplyRule(
            id: 'r2',
            keyword: 'merhaba',
            reply: 'Selam! Mesajın için teşekkürler, en kısa sürede döneceğim 💜'),
      ];
    }
    _rollDay();
    final name = prefs.getString('username');
    if (prefs.getBool('loggedIn') == true && name != null) {
      await login(username: name, silent: true);
    }
    ready = true;
    notifyListeners();
  }

  Future<void> login({String? username, bool silent = false}) async {
    loading = true;
    notifyListeners();
    account = await service.connect(username: username);
    await refresh();
    loggedIn = true;
    loading = false;
    await prefs.setBool('loggedIn', true);
    await prefs.setString('username', account!.username);
    notifyListeners();
  }

  Future<void> logout() async {
    loggedIn = false;
    account = null;
    users = [];
    tab = 0;
    await prefs.setBool('loggedIn', false);
    notifyListeners();
  }

  Future<void> refresh() async {
    users = await service.users();
    posts = List.of(await service.posts());
    engagers = await service.engagers(users);
    change = await service.todayChange(users);
    notifyListeners();
  }

  void setTab(int i) {
    tab = i;
    notifyListeners();
  }

  // ---- Kredi / Premium ---------------------------------------------------
  Future<void> addCredits(int n) async {
    credits += n;
    await prefs.setInt('credits', credits);
    notifyListeners();
  }

  Future<bool> claimDailyBonus() async {
    if (!canClaimBonus) return false;
    _bonusDate = _today();
    await prefs.setString('bonusDate', _bonusDate);
    await addCredits(2);
    return true;
  }

  /// Satın alma simülasyonu. Gerçek ödeme için `in_app_purchase` paketini
  /// bağlayıp başarılı olduğunda bu metodu çağırın.
  Future<void> activatePremium(PremiumPlan plan) async {
    final start = isPremium ? premiumUntil! : DateTime.now();
    premiumUntil = start.add(Duration(days: plan.days));
    await prefs.setInt('premiumUntil', premiumUntil!.millisecondsSinceEpoch);
    notifyListeners();
  }

  // ---- Toplu işlemler ----------------------------------------------------
  Future<void> _saveCounters() async {
    await prefs.setString('actionsDate', _actionsDate);
    await prefs.setInt('actionsToday', actionsToday);
  }

  Future<int> _runJob(String label, List<Future<void> Function()> tasks) async {
    final info = JobInfo(label, tasks.length);
    job = info;
    notifyListeners();
    for (final t in tasks) {
      _rollDay();
      if (info.cancelled || remainingActions <= 0) break;
      await t();
      actionsToday++;
      info.done++;
      await _saveCounters();
      notifyListeners();
      await Future.delayed(jobGap);
    }
    job = null;
    jobsCompleted++;
    notifyListeners();
    return info.done;
  }

  void cancelJob() {
    job?.cancelled = true;
    notifyListeners();
  }

  /// Hata mesajı döner, başarılıysa null.
  Future<String?> unfollowMany(List<IgUser> list) async {
    if (job != null) return 'Devam eden bir işlem var.';
    _rollDay();
    final n = min(list.length, remainingActions);
    if (list.isEmpty) return 'Kimse seçilmedi.';
    if (n == 0) return 'Günlük $dailyLimit işlem limitine ulaştın.';
    final cost = isPremium ? 0 : (n / unfollowsPerCredit).ceil();
    if (credits < cost) {
      return 'Yetersiz kredi ($cost gerekli). Reklam izle veya Premium\'a geç.';
    }
    if (cost > 0) await addCredits(-cost);
    final targets = list.take(n).toList();
    await _runJob(
      'Takipten çıkarılıyor',
      targets.map((u) => () => service.unfollow(u)).toList(),
    );
    return null;
  }

  Future<String?> likeBack(List<Engager> list) async {
    if (!isPremium) return 'Bu özellik Premium\'a özel.';
    if (job != null) return 'Devam eden bir işlem var.';
    _rollDay();
    if (remainingActions <= 0) return 'Günlük $dailyLimit işlem limitine ulaştın.';
    final tasks = <Future<void> Function()>[];
    for (final e in list) {
      final count = min(e.likes, 10);
      for (var i = 0; i < count; i++) {
        tasks.add(() => service.likePost(e.user, i));
      }
    }
    final names = list.length == 1 ? '@${list.first.user.username}' : '${list.length} kişi';
    await _runJob('$names beğeniliyor', tasks);
    for (final e in list) {
      likedBack.add(e.user.username);
    }
    notifyListeners();
    return null;
  }

  Future<String?> deletePost(IgPost p) async {
    if (job != null) return 'Devam eden bir işlem var.';
    _rollDay();
    if (remainingActions <= 0) return 'Günlük $dailyLimit işlem limitine ulaştın.';
    await service.deletePost(p);
    posts.removeWhere((x) => x.id == p.id);
    actionsToday++;
    await _saveCounters();
    notifyListeners();
    return null;
  }

  // ---- Otomatik yanıt ----------------------------------------------------
  Future<void> setAutoReply(bool v) async {
    autoReplyOn = v;
    await prefs.setBool('autoReplyOn', v);
    notifyListeners();
  }

  Future<void> _saveRules() async {
    await prefs.setString(
        'rules', jsonEncode(rules.map((r) => r.toJson()).toList()));
    notifyListeners();
  }

  Future<void> addRule(String keyword, String reply) async {
    rules.add(AutoReplyRule(
      id: DateTime.now().microsecondsSinceEpoch.toString(),
      keyword: keyword.trim(),
      reply: reply.trim(),
    ));
    await _saveRules();
  }

  Future<void> toggleRule(AutoReplyRule r, bool v) async {
    r.enabled = v;
    await _saveRules();
  }

  Future<void> removeRule(AutoReplyRule r) async {
    rules.remove(r);
    await _saveRules();
  }

  String? matchReply(String message) {
    final m = message.toLowerCase();
    for (final r in rules) {
      if (r.enabled && r.keyword.isNotEmpty && m.contains(r.keyword.toLowerCase())) {
        return r.reply;
      }
    }
    return null;
  }

  /// Gelen mesajı işler (demo/test). Eşleşme varsa log'a yazar.
  String? handleIncoming(String from, String message) {
    final reply = matchReply(message);
    if (reply != null && autoReplyOn && isPremium) {
      replyLog.insert(
        0,
        ReplyLogEntry(
            from: from, message: message, reply: reply, time: DateTime.now()),
      );
      notifyListeners();
    }
    return reply;
  }
}

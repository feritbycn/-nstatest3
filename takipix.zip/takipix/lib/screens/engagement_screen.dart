import 'package:flutter/material.dart';

import '../models.dart';
import '../state/app_state.dart';
import '../theme.dart';
import '../widgets/common.dart';

class EngagementScreen extends StatelessWidget {
  const EngagementScreen({super.key});

  static const freeVisible = 5;

  Future<void> _like(BuildContext context, AppState app, List<Engager> list) async {
    final err = await app.likeBack(list);
    if (context.mounted && err != null) {
      toast(context, err);
      if (!app.isPremium) app.setTab(4);
    } else if (context.mounted) {
      toast(context, 'Beğeni işlemi tamamlandı 💜');
    }
  }

  @override
  Widget build(BuildContext context) {
    final app = AppScope.of(context);
    final all = app.engagers;
    final visible = app.isPremium ? all : all.take(freeVisible).toList();
    final hiddenCount = all.length - visible.length;

    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 4, 16, 24),
      children: [
        const SectionTitle('En çok etkileşim yapanlar'),
        const Padding(
          padding: EdgeInsets.fromLTRB(4, 0, 4, 12),
          child: Text(
            'Gönderilerini en çok beğenen ve yorum yapan kişiler. '
            'Puan = beğeni + yorum × 3.',
            style: TextStyle(color: AppColors.textDim, fontSize: 13),
          ),
        ),

        // Toplu aksiyon
        GlassCard(
          gradient: LinearGradient(
            colors: [
              AppColors.purple.withOpacity(0.35),
              AppColors.pink.withOpacity(0.25),
            ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(children: [
                const Icon(Icons.auto_awesome, color: AppColors.gold),
                const SizedBox(width: 10),
                const Expanded(
                  child: Text('Beğenenleri beğen',
                      style:
                          TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
                ),
                if (!app.isPremium) const LockChip(),
              ]),
              const SizedBox(height: 8),
              const Text(
                'Bir kişi senin 5 gönderini beğendiyse, onun da 5 gönderisi '
                'beğenilir. Beğeniler peş peşe değil, aralıklarla yapılır.',
                style: TextStyle(color: Colors.white70, fontSize: 13),
              ),
              const SizedBox(height: 14),
              GradientButton(
                label: 'İlk 5 kişiyi otomatik beğen',
                icon: Icons.favorite,
                onPressed: app.job != null || all.isEmpty
                    ? null
                    : () => _like(context, app, all.take(5).toList()),
              ),
            ],
          ),
        ),

        ...List.generate(visible.length, (i) {
          final e = visible[i];
          final done = app.likedBack.contains(e.user.username);
          return Container(
            margin: const EdgeInsets.only(bottom: 10),
            padding: const EdgeInsets.fromLTRB(14, 12, 10, 12),
            decoration: BoxDecoration(
              color: AppColors.surface,
              borderRadius: BorderRadius.circular(18),
              border: i == 0
                  ? Border.all(color: AppColors.gold.withOpacity(0.5))
                  : null,
            ),
            child: Row(
              children: [
                SizedBox(
                  width: 26,
                  child: Text('${i + 1}',
                      style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w900,
                          color: i == 0 ? AppColors.gold : AppColors.textDim)),
                ),
                Avatar(user: e.user, size: 42),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('@${e.user.username}',
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(fontWeight: FontWeight.w700)),
                      const SizedBox(height: 3),
                      Text('${e.likes} beğeni · ${e.comments} yorum',
                          style: const TextStyle(
                              color: AppColors.textDim, fontSize: 12)),
                    ],
                  ),
                ),
                done
                    ? const Padding(
                        padding: EdgeInsets.all(10),
                        child: Icon(Icons.check_circle, color: AppColors.green),
                      )
                    : FilledButton.tonal(
                        onPressed: app.job != null
                            ? null
                            : () => _like(context, app, [e]),
                        style: FilledButton.styleFrom(
                          padding: const EdgeInsets.symmetric(horizontal: 12),
                        ),
                        child: Row(mainAxisSize: MainAxisSize.min, children: [
                          Text('${e.likes > 10 ? 10 : e.likes}'),
                          const SizedBox(width: 4),
                          const Icon(Icons.favorite, size: 16),
                        ]),
                      ),
              ],
            ),
          );
        }),

        if (hiddenCount > 0)
          GlassCard(
            onTap: () => app.setTab(4),
            child: Row(
              children: [
                const Icon(Icons.lock, color: AppColors.gold),
                const SizedBox(width: 12),
                Expanded(
                  child: Text('Diğer $hiddenCount kişiyi görmek için Premium\'a geç',
                      style: const TextStyle(fontWeight: FontWeight.w700)),
                ),
                const Icon(Icons.chevron_right),
              ],
            ),
          ),
      ],
    );
  }
}

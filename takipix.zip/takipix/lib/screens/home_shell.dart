import 'package:flutter/material.dart';

import '../services/ad_service.dart';
import '../state/app_state.dart';
import '../theme.dart';
import '../widgets/common.dart';
import 'dashboard_screen.dart';
import 'engagement_screen.dart';
import 'follow_screen.dart';
import 'messages_screen.dart';
import 'premium_screen.dart';

class HomeShell extends StatefulWidget {
  const HomeShell({super.key});

  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int _seenJobs = 0;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      final app = AppScope.of(context);
      _seenJobs = app.jobsCompleted;
      // Uygulama açılışında bir kez reklam (Premium hariç)
      if (!app.isPremium && !AdService.welcomeShown) {
        AdService.welcomeShown = true;
        await AdService.showInterstitial(context);
      }
    });
  }

  Future<void> _maybeAdAfterJob(AppState app) async {
    if (app.jobsCompleted != _seenJobs) {
      _seenJobs = app.jobsCompleted;
      // Her 2. işlemden sonra reklam
      if (!app.isPremium && app.jobsCompleted % 2 == 0) {
        await Future.delayed(const Duration(milliseconds: 400));
        if (mounted) await AdService.showInterstitial(context);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final app = AppScope.of(context);
    WidgetsBinding.instance.addPostFrameCallback((_) => _maybeAdAfterJob(app));

    const pages = <Widget>[
      DashboardScreen(),
      FollowScreen(),
      EngagementScreen(),
      MessagesScreen(),
      PremiumScreen(),
    ];

    return Scaffold(
      appBar: AppBar(
        titleSpacing: 16,
        title: Row(
          children: [
            const LogoMark(size: 30),
            const SizedBox(width: 10),
            const Text('Takipix',
                style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: -0.5)),
            if (app.isPremium) ...[
              const SizedBox(width: 8),
              const PremiumBadge(small: true),
            ],
          ],
        ),
        actions: [
          if (!app.isPremium)
            Padding(
              padding: const EdgeInsets.only(right: 12),
              child: ActionChip(
                backgroundColor: AppColors.surface2,
                side: BorderSide.none,
                avatar: const Icon(Icons.bolt, color: AppColors.gold, size: 18),
                label: Text('${app.credits}',
                    style: const TextStyle(fontWeight: FontWeight.w800)),
                onPressed: () => showCreditSheet(context),
              ),
            ),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: AnimatedSwitcher(
              duration: const Duration(milliseconds: 250),
              child: KeyedSubtree(
                key: ValueKey(app.tab),
                child: pages[app.tab],
              ),
            ),
          ),
          if (app.job != null) _JobBar(app: app),
          if (!app.isPremium) const AdBanner(),
        ],
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: app.tab,
        onDestinationSelected: app.setTab,
        destinations: const [
          NavigationDestination(
              icon: Icon(Icons.dashboard_outlined),
              selectedIcon: Icon(Icons.dashboard),
              label: 'Panel'),
          NavigationDestination(
              icon: Icon(Icons.people_outline),
              selectedIcon: Icon(Icons.people),
              label: 'Takip'),
          NavigationDestination(
              icon: Icon(Icons.favorite_border),
              selectedIcon: Icon(Icons.favorite),
              label: 'Etkileşim'),
          NavigationDestination(
              icon: Icon(Icons.chat_bubble_outline),
              selectedIcon: Icon(Icons.chat_bubble),
              label: 'Mesaj'),
          NavigationDestination(
              icon: Icon(Icons.workspace_premium_outlined),
              selectedIcon: Icon(Icons.workspace_premium),
              label: 'Premium'),
        ],
      ),
    );
  }
}

class _JobBar extends StatelessWidget {
  const _JobBar({required this.app});
  final AppState app;

  @override
  Widget build(BuildContext context) {
    final j = app.job!;
    return Container(
      margin: const EdgeInsets.fromLTRB(12, 4, 12, 8),
      padding: const EdgeInsets.fromLTRB(16, 12, 8, 12),
      decoration: BoxDecoration(
        color: AppColors.surface2,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: AppColors.pink.withOpacity(0.4)),
      ),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('${j.label}  ${j.done}/${j.total}',
                    style: const TextStyle(fontWeight: FontWeight.w700)),
                const SizedBox(height: 8),
                ClipRRect(
                  borderRadius: BorderRadius.circular(6),
                  child: LinearProgressIndicator(
                    value: j.total == 0 ? 0 : j.done / j.total,
                    minHeight: 6,
                    backgroundColor: Colors.white10,
                    valueColor: const AlwaysStoppedAnimation(AppColors.pink),
                  ),
                ),
              ],
            ),
          ),
          TextButton(onPressed: app.cancelJob, child: const Text('Durdur')),
        ],
      ),
    );
  }
}

/// Kredi kazanma alt paneli (ödüllü reklam).
Future<void> showCreditSheet(BuildContext context) {
  final app = AppScope.of(context);
  return showModalBottomSheet(
    context: context,
    backgroundColor: AppColors.surface,
    shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(28))),
    builder: (sheetCtx) {
      return Padding(
        padding: const EdgeInsets.fromLTRB(20, 20, 20, 28),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.bolt, size: 44, color: AppColors.gold),
            const SizedBox(height: 8),
            Text('${app.credits} kredin var',
                style:
                    const TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
            const SizedBox(height: 6),
            Text(
              'Her ${AppState.unfollowsPerCredit} takipten çıkarma 1 kredi. '
              'Reklam izleyerek kredi kazan.',
              textAlign: TextAlign.center,
              style: const TextStyle(color: AppColors.textDim),
            ),
            const SizedBox(height: 20),
            GradientButton(
              label: 'Reklam izle  +${AppState.rewardCredits} kredi',
              icon: Icons.play_circle_fill,
              onPressed: () async {
                Navigator.pop(sheetCtx);
                final ok = await AdService.showRewarded(context);
                if (ok) {
                  await app.addCredits(AppState.rewardCredits);
                  if (context.mounted) {
                    toast(context, '+${AppState.rewardCredits} kredi kazandın!');
                  }
                }
              },
            ),
            const SizedBox(height: 10),
            if (app.canClaimBonus)
              OutlinedButton.icon(
                onPressed: () async {
                  Navigator.pop(sheetCtx);
                  await app.claimDailyBonus();
                  if (context.mounted) toast(context, 'Günlük hediye: +2 kredi 🎁');
                },
                icon: const Icon(Icons.card_giftcard),
                label: const Text('Günlük hediyeni al (+2)'),
              ),
            TextButton(
              onPressed: () {
                Navigator.pop(sheetCtx);
                app.setTab(4);
              },
              child: const Text('Sınırsız için Premium\'a geç'),
            ),
          ],
        ),
      );
    },
  );
}

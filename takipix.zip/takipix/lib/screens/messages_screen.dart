import 'dart:math';

import 'package:flutter/material.dart';

import '../models.dart';
import '../state/app_state.dart';
import '../theme.dart';
import '../widgets/common.dart';

class MessagesScreen extends StatefulWidget {
  const MessagesScreen({super.key});

  @override
  State<MessagesScreen> createState() => _MessagesScreenState();
}

class _MessagesScreenState extends State<MessagesScreen> {
  final _test = TextEditingController();
  String? _testResult;

  @override
  void dispose() {
    _test.dispose();
    super.dispose();
  }

  Future<void> _addRule(AppState app) async {
    final kw = TextEditingController();
    final reply = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: AppColors.surface,
        title: const Text('Yeni kural'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: kw,
              decoration: const InputDecoration(
                labelText: 'Anahtar kelime',
                hintText: 'örn. fiyat',
              ),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: reply,
              maxLines: 3,
              decoration: const InputDecoration(
                labelText: 'Otomatik cevap',
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('Vazgeç')),
          TextButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('Kaydet')),
        ],
      ),
    );
    if (ok == true && kw.text.trim().isNotEmpty && reply.text.trim().isNotEmpty) {
      await app.addRule(kw.text, reply.text);
    }
    kw.dispose();
    reply.dispose();
  }

  void _simulate(AppState app) {
    final enabled = app.rules.where((r) => r.enabled).toList();
    if (enabled.isEmpty) {
      toast(context, 'Önce en az bir kural ekle.');
      return;
    }
    final rnd = Random();
    final rule = enabled[rnd.nextInt(enabled.length)];
    final from = app.users.isEmpty
        ? 'kullanici'
        : app.users[rnd.nextInt(app.users.length)].username;
    if (!app.isPremium || !app.autoReplyOn) {
      toast(context, 'Önce Premium ol ve otomatik yanıtı aç.');
      return;
    }
    app.handleIncoming(from, 'Selam, ${rule.keyword} hakkında bilgi alabilir miyim?');
  }

  @override
  Widget build(BuildContext context) {
    final app = AppScope.of(context);

    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 4, 16, 24),
      children: [
        GlassCard(
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  gradient: AppColors.gradient,
                  borderRadius: BorderRadius.circular(14),
                ),
                child: const Icon(Icons.smart_toy_rounded),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(children: [
                      const Text('Otomatik yanıt',
                          style: TextStyle(
                              fontSize: 17, fontWeight: FontWeight.w800)),
                      const SizedBox(width: 8),
                      if (!app.isPremium) const LockChip(),
                    ]),
                    const SizedBox(height: 2),
                    const Text('Anahtar kelime gelince DM\'e otomatik cevap.',
                        style: TextStyle(color: AppColors.textDim, fontSize: 12)),
                  ],
                ),
              ),
              Switch(
                value: app.autoReplyOn && app.isPremium,
                onChanged: (v) {
                  if (!app.isPremium) {
                    toast(context, 'Otomatik yanıt Premium\'a özel.');
                    app.setTab(4);
                    return;
                  }
                  app.setAutoReply(v);
                },
              ),
            ],
          ),
        ),

        SectionTitle('Kurallar',
            trailing: TextButton.icon(
              onPressed: () => _addRule(app),
              icon: const Icon(Icons.add),
              label: const Text('Ekle'),
            )),
        if (app.rules.isEmpty)
          const GlassCard(
              child: Text('Henüz kural yok.',
                  style: TextStyle(color: AppColors.textDim))),
        ...app.rules.map((r) => _RuleTile(rule: r, app: app)),

        const SectionTitle('Kuralı dene'),
        GlassCard(
          child: Column(
            children: [
              TextField(
                controller: _test,
                decoration: InputDecoration(
                  hintText: 'Gelen mesajı yaz, hangi cevabın gideceğini gör',
                  filled: true,
                  fillColor: AppColors.surface2,
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(14),
                    borderSide: BorderSide.none,
                  ),
                  suffixIcon: IconButton(
                    icon: const Icon(Icons.send_rounded, color: AppColors.pink),
                    onPressed: () => setState(() {
                      _testResult = app.matchReply(_test.text) ??
                          'Eşleşen kural yok — cevap gönderilmez.';
                    }),
                  ),
                ),
              ),
              if (_testResult != null) ...[
                const SizedBox(height: 12),
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: AppColors.purple.withOpacity(0.25),
                    borderRadius: BorderRadius.circular(14),
                  ),
                  child: Text(_testResult!),
                ),
              ],
            ],
          ),
        ),

        SectionTitle('Gönderilen cevaplar',
            trailing: TextButton(
              onPressed: () => _simulate(app),
              child: const Text('Demo mesaj'),
            )),
        if (app.replyLog.isEmpty)
          const GlassCard(
            child: Text(
              'Otomatik yanıt açıkken gelen mesajlar ve verilen cevaplar burada görünür.',
              style: TextStyle(color: AppColors.textDim),
            ),
          ),
        ...app.replyLog.take(20).map(_logTile),
      ],
    );
  }

  Widget _logTile(ReplyLogEntry e) {
    return GlassCard(
      padding: const EdgeInsets.all(14),
      margin: const EdgeInsets.only(bottom: 10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('@${e.from}',
              style: const TextStyle(fontWeight: FontWeight.w800)),
          const SizedBox(height: 4),
          Text(e.message, style: const TextStyle(color: AppColors.textDim)),
          const Divider(height: 18, color: Colors.white10),
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Icon(Icons.reply, size: 16, color: AppColors.pink),
              const SizedBox(width: 6),
              Expanded(child: Text(e.reply)),
            ],
          ),
        ],
      ),
    );
  }
}

class _RuleTile extends StatelessWidget {
  const _RuleTile({required this.rule, required this.app});
  final AutoReplyRule rule;
  final AppState app;

  @override
  Widget build(BuildContext context) {
    return GlassCard(
      padding: const EdgeInsets.fromLTRB(16, 12, 8, 12),
      margin: const EdgeInsets.only(bottom: 10),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
                  decoration: BoxDecoration(
                    color: AppColors.pink.withOpacity(0.18),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Text('“${rule.keyword}”',
                      style: const TextStyle(
                          color: AppColors.pink, fontWeight: FontWeight.w800)),
                ),
                const SizedBox(height: 8),
                Text(rule.reply,
                    style: const TextStyle(color: AppColors.textDim)),
              ],
            ),
          ),
          Column(
            children: [
              Switch(
                value: rule.enabled,
                onChanged: (v) => app.toggleRule(rule, v),
              ),
              IconButton(
                onPressed: () => app.removeRule(rule),
                icon: const Icon(Icons.delete_outline,
                    size: 20, color: AppColors.red),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

import 'package:flutter/material.dart';

import '../models.dart';
import '../state/app_state.dart';
import '../theme.dart';
import '../widgets/common.dart';

class DashboardScreen extends StatelessWidget {
  const DashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final app = AppScope.of(context);
    final acc = app.account;
    final change = app.change;
    final top = app.topVideo;

    return RefreshIndicator(
      onRefresh: app.refresh,
      child: ListView(
        padding: const EdgeInsets.fromLTRB(16, 4, 16, 24),
        children: [
          // Profil kartı
          GlassCard(
            gradient: AppColors.gradient,
            child: Row(
              children: [
                CircleAvatar(
                  radius: 28,
                  backgroundColor: Colors.white24,
                  child: Text(
                    (acc?.username ?? '?').substring(0, 1).toUpperCase(),
                    style: const TextStyle(
                        fontSize: 24, fontWeight: FontWeight.w900),
                  ),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(children: [
                        Flexible(
                          child: Text('@${acc?.username ?? ''}',
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(
                                  fontSize: 18, fontWeight: FontWeight.w800)),
                        ),
                        if (app.isPremium) ...[
                          const SizedBox(width: 8),
                          const PremiumBadge(),
                        ],
                      ]),
                      const SizedBox(height: 2),
                      Text(
                        app.isPremium ? 'Premium üye' : 'Ücretsiz hesap',
                        style: const TextStyle(color: Colors.white70),
                      ),
                    ],
                  ),
                ),
                IconButton(
                  tooltip: 'Çıkış',
                  onPressed: app.logout,
                  icon: const Icon(Icons.logout, color: Colors.white),
                ),
              ],
            ),
          ),

          // İstatistikler
          Row(
            children: [
              _Stat('Takipçi', app.followers.length, Icons.groups_rounded),
              const SizedBox(width: 10),
              _Stat('Takip', app.following.length, Icons.person_add_alt_1),
              const SizedBox(width: 10),
              _Stat('Karşılıklı', app.mutual.length, Icons.sync_alt),
            ],
          ),
          const SizedBox(height: 14),

          // Bugün
          if (change != null) ...[
            const SectionTitle('Bugün'),
            Row(
              children: [
                Expanded(
                  child: _DeltaCard(
                    title: 'Kazanılan',
                    value: '+${change.gained.length}',
                    color: AppColors.green,
                    icon: Icons.trending_up,
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: _DeltaCard(
                    title: 'Kaybedilen',
                    value: '-${change.lost.length}',
                    color: AppColors.red,
                    icon: Icons.trending_down,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 14),
            _UserExpansion(
              title: 'Yeni takipçiler',
              users: change.gained,
              color: AppColors.green,
            ),
            _UserExpansion(
              title: 'Takibi bırakanlar',
              users: change.lost,
              color: AppColors.red,
            ),
          ],

          // Günlük limit
          GlassCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(children: [
                  const Icon(Icons.speed, color: AppColors.pink),
                  const SizedBox(width: 10),
                  const Expanded(
                    child: Text('Günlük işlem limiti',
                        style: TextStyle(fontWeight: FontWeight.w700)),
                  ),
                  Text('${app.actionsToday}/${AppState.dailyLimit}',
                      style: const TextStyle(fontWeight: FontWeight.w800)),
                ]),
                const SizedBox(height: 12),
                LimitBar(used: app.actionsToday, limit: AppState.dailyLimit),
                const SizedBox(height: 8),
                const Text(
                  'Hesabını korumak için takipten çıkarma, beğeni ve silme '
                  'işlemleri günde en fazla 150 ile sınırlı.',
                  style: TextStyle(color: AppColors.textDim, fontSize: 12),
                ),
              ],
            ),
          ),

          // En çok izlenen video
          const SectionTitle('En çok izlenen video'),
          if (top == null)
            const GlassCard(child: Text('Video bulunamadı.'))
          else
            _VideoCard(post: top, featured: true),

          SectionTitle('Tüm gönderiler',
              trailing: Text('${app.posts.length}',
                  style: const TextStyle(color: AppColors.textDim))),
          ...(() {
            final sorted = List<IgPost>.from(app.posts)
              ..sort((a, b) => b.views.compareTo(a.views));
            return sorted.map((p) => _VideoCard(post: p));
          })(),
        ],
      ),
    );
  }
}

class _Stat extends StatelessWidget {
  const _Stat(this.label, this.value, this.icon);
  final String label;
  final int value;
  final IconData icon;

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 16),
        decoration: BoxDecoration(
          color: AppColors.surface,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: Colors.white.withOpacity(0.06)),
        ),
        child: Column(
          children: [
            Icon(icon, color: AppColors.pink, size: 22),
            const SizedBox(height: 8),
            Text('$value',
                style: const TextStyle(
                    fontSize: 22, fontWeight: FontWeight.w900)),
            Text(label,
                style: const TextStyle(color: AppColors.textDim, fontSize: 12)),
          ],
        ),
      ),
    );
  }
}

class _DeltaCard extends StatelessWidget {
  const _DeltaCard({
    required this.title,
    required this.value,
    required this.color,
    required this.icon,
  });
  final String title;
  final String value;
  final Color color;
  final IconData icon;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: color.withOpacity(0.12),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: color.withOpacity(0.3)),
      ),
      child: Row(
        children: [
          Icon(icon, color: color),
          const SizedBox(width: 10),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(value,
                  style: TextStyle(
                      fontSize: 24, fontWeight: FontWeight.w900, color: color)),
              Text(title,
                  style:
                      const TextStyle(color: AppColors.textDim, fontSize: 12)),
            ],
          ),
        ],
      ),
    );
  }
}

class _UserExpansion extends StatelessWidget {
  const _UserExpansion({
    required this.title,
    required this.users,
    required this.color,
  });
  final String title;
  final List<IgUser> users;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(18),
      ),
      child: Theme(
        data: Theme.of(context).copyWith(dividerColor: Colors.transparent),
        child: ExpansionTile(
          tilePadding: const EdgeInsets.symmetric(horizontal: 16),
          title: Text(title, style: const TextStyle(fontWeight: FontWeight.w700)),
          trailing: Text('${users.length}',
              style: TextStyle(color: color, fontWeight: FontWeight.w800)),
          children: users
              .map((u) => ListTile(
                    dense: true,
                    leading: Avatar(user: u, size: 34),
                    title: Text('@${u.username}'),
                    subtitle: Text(u.name),
                  ))
              .toList(),
        ),
      ),
    );
  }
}

class _VideoCard extends StatelessWidget {
  const _VideoCard({required this.post, this.featured = false});
  final IgPost post;
  final bool featured;

  Future<void> _delete(BuildContext context) async {
    final app = AppScope.of(context);
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: AppColors.surface,
        title: const Text('Gönderi silinsin mi?'),
        content: Text('"${post.title}" kalıcı olarak silinecek. '
            'Bu işlem geri alınamaz.'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('Vazgeç')),
          TextButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('Sil',
                  style: TextStyle(color: AppColors.red))),
        ],
      ),
    );
    if (ok != true) return;
    final err = await app.deletePost(post);
    if (context.mounted) toast(context, err ?? 'Gönderi silindi.');
  }

  @override
  Widget build(BuildContext context) {
    return GlassCard(
      padding: const EdgeInsets.all(12),
      margin: EdgeInsets.only(bottom: featured ? 14 : 10),
      child: Row(
        children: [
          Container(
            width: featured ? 84 : 60,
            height: featured ? 84 : 60,
            decoration: BoxDecoration(
              gradient: AppColors.gradient,
              borderRadius: BorderRadius.circular(16),
            ),
            child: Icon(
              post.isVideo ? Icons.play_arrow_rounded : Icons.image_rounded,
              size: featured ? 40 : 30,
              color: Colors.white,
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(post.title,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                        fontWeight: FontWeight.w800, fontSize: 15)),
                const SizedBox(height: 6),
                Wrap(spacing: 12, children: [
                  _Meta(Icons.visibility, fmt(post.views)),
                  _Meta(Icons.favorite, fmt(post.likes)),
                  _Meta(Icons.chat_bubble, fmt(post.comments)),
                ]),
              ],
            ),
          ),
          IconButton(
            tooltip: 'Sil',
            onPressed: () => _delete(context),
            icon: const Icon(Icons.delete_outline, color: AppColors.red),
          ),
        ],
      ),
    );
  }
}

class _Meta extends StatelessWidget {
  const _Meta(this.icon, this.text);
  final IconData icon;
  final String text;

  @override
  Widget build(BuildContext context) {
    return Row(mainAxisSize: MainAxisSize.min, children: [
      Icon(icon, size: 13, color: AppColors.textDim),
      const SizedBox(width: 4),
      Text(text, style: const TextStyle(color: AppColors.textDim, fontSize: 12)),
    ]);
  }
}

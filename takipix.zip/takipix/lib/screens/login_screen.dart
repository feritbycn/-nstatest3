import 'package:flutter/material.dart';

import '../state/app_state.dart';
import '../theme.dart';
import '../widgets/common.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _user = TextEditingController();

  @override
  void dispose() {
    _user.dispose();
    super.dispose();
  }

  Future<void> _connect(AppState app, {String? name}) async {
    FocusScope.of(context).unfocus();
    await app.login(username: name);
  }

  @override
  Widget build(BuildContext context) {
    final app = AppScope.of(context);
    return Scaffold(
      body: Stack(
        children: [
          Positioned(
            top: -120,
            right: -80,
            child: _Glow(color: AppColors.purple.withOpacity(0.45), size: 320),
          ),
          Positioned(
            bottom: -140,
            left: -100,
            child: _Glow(color: AppColors.pink.withOpacity(0.35), size: 340),
          ),
          SafeArea(
            child: Center(
              child: SingleChildScrollView(
                padding: const EdgeInsets.symmetric(horizontal: 24),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const LogoMark(size: 96),
                    const SizedBox(height: 22),
                    ShaderMask(
                      shaderCallback: (r) => AppColors.gradient.createShader(r),
                      child: const Text(
                        'Takipix',
                        style: TextStyle(
                          fontSize: 38,
                          fontWeight: FontWeight.w900,
                          color: Colors.white,
                          letterSpacing: -1,
                        ),
                      ),
                    ),
                    const SizedBox(height: 8),
                    const Text(
                      'Takipçilerini tanı, hesabını akıllıca yönet.',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: AppColors.textDim, fontSize: 15),
                    ),
                    const SizedBox(height: 34),
                    GradientButton(
                      label: 'Instagram ile bağlan',
                      icon: Icons.camera_alt_rounded,
                      loading: app.loading,
                      onPressed: () => _connect(app),
                    ),
                    const SizedBox(height: 22),
                    Row(children: const [
                      Expanded(child: Divider(color: Colors.white12)),
                      Padding(
                        padding: EdgeInsets.symmetric(horizontal: 12),
                        child: Text('veya',
                            style: TextStyle(color: AppColors.textDim)),
                      ),
                      Expanded(child: Divider(color: Colors.white12)),
                    ]),
                    const SizedBox(height: 22),
                    TextField(
                      controller: _user,
                      autocorrect: false,
                      decoration: InputDecoration(
                        hintText: 'Instagram kullanıcı adı',
                        prefixIcon: const Icon(Icons.alternate_email),
                        filled: true,
                        fillColor: AppColors.surface,
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(16),
                          borderSide: BorderSide.none,
                        ),
                      ),
                    ),
                    const SizedBox(height: 12),
                    SizedBox(
                      width: double.infinity,
                      child: OutlinedButton(
                        style: OutlinedButton.styleFrom(
                          padding: const EdgeInsets.symmetric(vertical: 15),
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(16)),
                          side: const BorderSide(color: Colors.white24),
                        ),
                        onPressed: app.loading
                            ? null
                            : () => _connect(app, name: _user.text),
                        child: const Text('Kullanıcı adıyla devam et'),
                      ),
                    ),
                    const SizedBox(height: 22),
                    const Text(
                      'Demo sürüm: gerçek Instagram verisi yerine örnek hesap '
                      'verisiyle çalışır. Şifre istenmez ve saklanmaz.',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: AppColors.textDim, fontSize: 12),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _Glow extends StatelessWidget {
  const _Glow({required this.color, required this.size});
  final Color color;
  final double size;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: RadialGradient(colors: [color, Colors.transparent]),
      ),
    );
  }
}

import 'package:flutter/material.dart';

import '../models.dart';
import '../services/ad_service.dart';
import '../state/app_state.dart';
import '../theme.dart';
import '../widgets/common.dart';

class PremiumScreen extends StatefulWidget {
  const PremiumScreen({super.key});

  @override
  State<PremiumScreen> createState() => _PremiumScreenState();
}

class _PremiumScreenState extends State<PremiumScreen> {
  PremiumPlan _plan = AppState.plans[1];
  bool _buying = false;

  // (özellik, ücretsiz, premium)
  static const _rows = <(String, String, String)>[
    ('Takipçi analizi ve günlük değişim', '✓', '✓'),
    ('Geri takip etmeyenleri bulma', '✓', '✓'),
    ('Takipten çıkarma', '5 kişi = 1 kredi', 'Sınırsız*'),
    ('Video / gönderi silme', '✓', '✓'),
    ('Etkileşim sıralaması', 'İlk 5 kişi', 'Tüm liste'),
    ('Beğenenleri otomatik beğen', '—', '✓'),
    ('Otomatik mesaj yanıtlama', '—', '✓'),
    ('Reklamlar', 'Var', 'Yok'),
    ('PRO rozeti', '—', '✓'),
  ];

  Future<void> _buy(AppState app) async {
    setState(() => _buying = true);
    // Gerçek ödeme: in_app_purchase ile satın alma tamamlanınca çağrılır.
    await Future.delayed(const Duration(milliseconds: 900));
    await app.activatePremium(_plan);
    if (!mounted) return;
    setState(() => _buying = false);
    toast(context, 'Premium aktif! 👑');
  }

  @override
  Widget build(BuildContext context) {
    final app = AppScope.of(context);

    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 4, 16, 28),
      children: [
        // Hero
        Container(
          padding: const EdgeInsets.all(22),
          margin: const EdgeInsets.only(bottom: 16),
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [Color(0xFF2A1B54), Color(0xFF6D1D5C)],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(28),
            border: Border.all(color: AppColors.gold.withOpacity(0.35)),
          ),
          child: Column(
            children: [
              Container(
                padding: const EdgeInsets.all(14),
                decoration: const BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: AppColors.goldGradient,
                ),
                child: const Icon(Icons.workspace_premium,
                    size: 38, color: Color(0xFF3B2A00)),
              ),
              const SizedBox(height: 14),
              Text(
                app.isPremium ? 'Premium üyesin' : 'Takipix Premium',
                style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w900),
              ),
              const SizedBox(height: 6),
              Text(
                app.isPremium
                    ? 'Bitiş: ${_date(app.premiumUntil!)}'
                    : 'Reklamsız, sınırsız ve otomatik.',
                style: const TextStyle(color: Colors.white70),
              ),
              if (app.isPremium) ...[
                const SizedBox(height: 10),
                const PremiumBadge(),
              ],
            ],
          ),
        ),

        // Özellik tablosu
        GlassCard(
          padding: const EdgeInsets.fromLTRB(16, 14, 16, 8),
          child: Column(
            children: [
              Row(children: const [
                Expanded(
                    flex: 5,
                    child: Text('Özellik',
                        style: TextStyle(
                            color: AppColors.textDim,
                            fontWeight: FontWeight.w700))),
                Expanded(
                    flex: 3,
                    child: Text('Ücretsiz',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                            color: AppColors.textDim,
                            fontWeight: FontWeight.w700))),
                Expanded(
                    flex: 3,
                    child: Text('Premium',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                            color: AppColors.gold, fontWeight: FontWeight.w800))),
              ]),
              const Divider(color: Colors.white12, height: 20),
              ..._rows.map((r) => Padding(
                    padding: const EdgeInsets.symmetric(vertical: 8),
                    child: Row(children: [
                      Expanded(
                          flex: 5,
                          child: Text(r.$1,
                              style: const TextStyle(fontSize: 13))),
                      Expanded(
                          flex: 3,
                          child: Text(r.$2,
                              textAlign: TextAlign.center,
                              style: const TextStyle(
                                  fontSize: 12, color: AppColors.textDim))),
                      Expanded(
                          flex: 3,
                          child: Text(r.$3,
                              textAlign: TextAlign.center,
                              style: const TextStyle(
                                  fontSize: 12,
                                  fontWeight: FontWeight.w800,
                                  color: AppColors.gold))),
                    ]),
                  )),
              const Padding(
                padding: EdgeInsets.only(top: 4, bottom: 6),
                child: Text(
                  '* Günlük ${AppState.dailyLimit} işlem güvenlik limiti geçerlidir.',
                  style: TextStyle(color: AppColors.textDim, fontSize: 11),
                ),
              ),
            ],
          ),
        ),

        // Planlar
        const SectionTitle('Plan seç'),
        ...AppState.plans.map((p) {
          final sel = p.id == _plan.id;
          return GestureDetector(
            onTap: () => setState(() => _plan = p),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              margin: const EdgeInsets.only(bottom: 10),
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: AppColors.surface,
                borderRadius: BorderRadius.circular(20),
                border: Border.all(
                  color: sel ? AppColors.gold : Colors.white10,
                  width: sel ? 2 : 1,
                ),
              ),
              child: Row(
                children: [
                  Icon(sel ? Icons.radio_button_checked : Icons.radio_button_off,
                      color: sel ? AppColors.gold : AppColors.textDim),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Row(children: [
                      Text(p.title,
                          style: const TextStyle(
                              fontSize: 16, fontWeight: FontWeight.w800)),
                      if (p.tag != null) ...[
                        const SizedBox(width: 8),
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 7, vertical: 2),
                          decoration: BoxDecoration(
                            color: AppColors.pink,
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: Text(p.tag!,
                              style: const TextStyle(
                                  fontSize: 9, fontWeight: FontWeight.w900)),
                        ),
                      ],
                    ]),
                  ),
                  Text(p.price,
                      style: const TextStyle(
                          fontSize: 16, fontWeight: FontWeight.w900)),
                ],
              ),
            ),
          );
        }),
        const SizedBox(height: 6),
        GradientButton(
          label: app.isPremium ? 'Süreyi uzat' : 'Premium\'a geç',
          icon: Icons.workspace_premium,
          gradient: AppColors.goldGradient,
          foreground: const Color(0xFF3B2A00),
          loading: _buying,
          onPressed: () => _buy(app),
        ),
        const SizedBox(height: 8),
        const Center(
          child: Text(
            'Demo: ödeme simülasyonudur. Gerçek ödeme için in_app_purchase bağlanır.',
            textAlign: TextAlign.center,
            style: TextStyle(color: AppColors.textDim, fontSize: 11),
          ),
        ),

        // Kredi
        if (!app.isPremium) ...[
          const SectionTitle('Ücretsiz kredi kazan'),
          GlassCard(
            child: Row(
              children: [
                const Icon(Icons.bolt, color: AppColors.gold, size: 34),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('${app.credits} kredi',
                          style: const TextStyle(
                              fontSize: 18, fontWeight: FontWeight.w900)),
                      const Text('Reklam izle, +3 kredi kazan.',
                          style: TextStyle(
                              color: AppColors.textDim, fontSize: 12)),
                    ],
                  ),
                ),
                FilledButton(
                  onPressed: () async {
                    final ok = await AdService.showRewarded(context);
                    if (ok) {
                      await app.addCredits(AppState.rewardCredits);
                      if (context.mounted) {
                        toast(context, '+${AppState.rewardCredits} kredi!');
                      }
                    }
                  },
                  child: const Text('İzle'),
                ),
              ],
            ),
          ),
        ],
      ],
    );
  }

  String _date(DateTime d) =>
      '${d.day.toString().padLeft(2, '0')}.${d.month.toString().padLeft(2, '0')}.${d.year}';
}

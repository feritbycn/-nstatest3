import 'package:flutter/material.dart';

import '../models.dart';
import '../state/app_state.dart';
import '../theme.dart';
import '../widgets/common.dart';

class FollowScreen extends StatefulWidget {
  const FollowScreen({super.key});

  @override
  State<FollowScreen> createState() => _FollowScreenState();
}

class _FollowScreenState extends State<FollowScreen> {
  int _seg = 0; // 0: geri takip etmeyenler, 1: hayranlar, 2: karşılıklı
  final Set<String> _selected = {};

  List<IgUser> _list(AppState app) {
    switch (_seg) {
      case 0:
        return app.notFollowingBack;
      case 1:
        return app.fans;
      default:
        return app.mutual;
    }
  }

  Future<void> _unfollow(AppState app, List<IgUser> targets) async {
    final n = targets.length;
    final cost = app.isPremium ? 0 : (n / AppState.unfollowsPerCredit).ceil();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: AppColors.surface,
        title: Text('$n kişi takipten çıkarılsın mı?'),
        content: Text(app.isPremium
            ? 'İşlem güvenlik için aralıklarla yapılır.'
            : 'Bu işlem $cost kredi harcar. İşlem güvenlik için aralıklarla yapılır.'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('Vazgeç')),
          TextButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('Başlat')),
        ],
      ),
    );
    if (ok != true) return;
    _selected.removeAll(targets.map((e) => e.username));
    final err = await app.unfollowMany(targets);
    if (mounted && err != null) toast(context, err);
  }

  @override
  Widget build(BuildContext context) {
    final app = AppScope.of(context);
    final list = _list(app);
    final selected =
        list.where((u) => _selected.contains(u.username)).toList();
    final canUnfollow = _seg == 0 || _seg == 2;

    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 4, 16, 8),
          child: SizedBox(
            width: double.infinity,
            child: SegmentedButton<int>(
              showSelectedIcon: false,
              segments: [
                ButtonSegment(
                    value: 0, label: Text('Geri takip\n${app.notFollowingBack.length}', textAlign: TextAlign.center)),
                ButtonSegment(
                    value: 1, label: Text('Hayranlar\n${app.fans.length}', textAlign: TextAlign.center)),
                ButtonSegment(
                    value: 2, label: Text('Karşılıklı\n${app.mutual.length}', textAlign: TextAlign.center)),
              ],
              selected: {_seg},
              onSelectionChanged: (s) => setState(() {
                _seg = s.first;
                _selected.clear();
              }),
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: Text(
            _seg == 0
                ? 'Takip ettiğin ama seni takip etmeyenler'
                : _seg == 1
                    ? 'Seni takip eden ama senin takip etmediklerin'
                    : 'Birbirinizi takip ediyorsunuz',
            style: const TextStyle(color: AppColors.textDim, fontSize: 13),
          ),
        ),
        if (canUnfollow && list.isNotEmpty)
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 4, 12, 0),
            child: Row(
              children: [
                Checkbox(
                  value: selected.length == list.length && list.isNotEmpty,
                  onChanged: (v) => setState(() {
                    if (v == true) {
                      _selected.addAll(list.map((e) => e.username));
                    } else {
                      _selected.clear();
                    }
                  }),
                ),
                const Text('Tümünü seç'),
                const Spacer(),
                Text('${selected.length} seçili',
                    style: const TextStyle(color: AppColors.textDim)),
              ],
            ),
          ),
        Expanded(
          child: list.isEmpty
              ? const Center(
                  child: Text('Bu listede kimse yok 🎉',
                      style: TextStyle(color: AppColors.textDim)))
              : ListView.builder(
                  padding: const EdgeInsets.fromLTRB(16, 4, 16, 16),
                  itemCount: list.length,
                  itemBuilder: (context, i) {
                    final u = list[i];
                    final checked = _selected.contains(u.username);
                    return Container(
                      margin: const EdgeInsets.only(bottom: 8),
                      decoration: BoxDecoration(
                        color: AppColors.surface,
                        borderRadius: BorderRadius.circular(16),
                      ),
                      child: ListTile(
                        onTap: canUnfollow
                            ? () => setState(() {
                                  checked
                                      ? _selected.remove(u.username)
                                      : _selected.add(u.username);
                                })
                            : null,
                        leading: Avatar(user: u),
                        title: Text('@${u.username}',
                            style: const TextStyle(fontWeight: FontWeight.w700)),
                        subtitle: Text(u.name),
                        trailing: canUnfollow
                            ? Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Checkbox(
                                    value: checked,
                                    onChanged: (v) => setState(() {
                                      v == true
                                          ? _selected.add(u.username)
                                          : _selected.remove(u.username);
                                    }),
                                  ),
                                ],
                              )
                            : null,
                      ),
                    );
                  },
                ),
        ),
        if (canUnfollow)
          SafeArea(
            top: false,
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 4, 16, 8),
              child: GradientButton(
                label: selected.isEmpty
                    ? 'Takipten çıkarmak için seç'
                    : 'Takipten çıkar (${selected.length})',
                icon: Icons.person_remove_alt_1,
                onPressed: selected.isEmpty || app.job != null
                    ? null
                    : () => _unfollow(app, selected),
              ),
            ),
          ),
      ],
    );
  }
}

import 'dart:async';

import 'package:flutter/material.dart';

import '../theme.dart';

/// Reklam katmanı (simülasyon).
///
/// Gerçek reklam için `google_mobile_ads` paketini ekleyin ve aşağıdaki
/// metodların içini AdMob çağrılarıyla değiştirin:
///   * [showInterstitial]  -> InterstitialAd.load(...) + show()
///   * [showRewarded]      -> RewardedAd.load(...) + show(onUserEarnedReward)
///   * [AdBanner]          -> BannerAd + AdWidget
/// Uygulama içindeki çağrı noktaları aynı kalır.
class AdService {
  static bool welcomeShown = false;

  /// Tam ekran reklam. Kapatıldığında tamamlanır.
  static Future<void> showInterstitial(BuildContext context) async {
    await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (_) => const _FakeAdDialog(seconds: 4, rewarded: false),
    );
  }

  /// Ödüllü reklam. İzleme tamamlanırsa true döner.
  static Future<bool> showRewarded(BuildContext context) async {
    final ok = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (_) => const _FakeAdDialog(seconds: 5, rewarded: true),
    );
    return ok ?? false;
  }
}

class _FakeAdDialog extends StatefulWidget {
  const _FakeAdDialog({required this.seconds, required this.rewarded});
  final int seconds;
  final bool rewarded;

  @override
  State<_FakeAdDialog> createState() => _FakeAdDialogState();
}

class _FakeAdDialogState extends State<_FakeAdDialog> {
  late int left = widget.seconds;
  Timer? timer;

  @override
  void initState() {
    super.initState();
    timer = Timer.periodic(const Duration(seconds: 1), (t) {
      if (left <= 1) {
        t.cancel();
      }
      if (mounted) setState(() => left--);
    });
  }

  @override
  void dispose() {
    timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final done = left <= 0;
    return Dialog(
      backgroundColor: AppColors.surface,
      insetPadding: const EdgeInsets.all(20),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Row(
              children: [
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                  decoration: BoxDecoration(
                    color: Colors.white12,
                    borderRadius: BorderRadius.circular(6),
                  ),
                  child: const Text('REKLAM',
                      style: TextStyle(fontSize: 10, letterSpacing: 1)),
                ),
                const Spacer(),
                Text(done ? '' : '$left sn',
                    style: const TextStyle(color: AppColors.textDim)),
              ],
            ),
            const SizedBox(height: 14),
            Container(
              height: 200,
              width: double.infinity,
              decoration: BoxDecoration(
                gradient: AppColors.gradient,
                borderRadius: BorderRadius.circular(18),
              ),
              child: const Center(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.play_circle_fill, size: 56, color: Colors.white),
                    SizedBox(height: 8),
                    Text('Reklam alanı',
                        style: TextStyle(
                            fontSize: 18, fontWeight: FontWeight.w700)),
                    Text('(AdMob buraya bağlanır)',
                        style: TextStyle(color: Colors.white70, fontSize: 12)),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),
            SizedBox(
              width: double.infinity,
              child: FilledButton(
                onPressed: done
                    ? () => Navigator.of(context).pop(widget.rewarded)
                    : null,
                child: Text(done
                    ? (widget.rewarded ? 'Ödülü al 🎁' : 'Kapat')
                    : 'Lütfen bekle...'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// Ekranın altında duran banner reklam alanı.
class AdBanner extends StatelessWidget {
  const AdBanner({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 52,
      margin: const EdgeInsets.fromLTRB(12, 0, 12, 6),
      decoration: BoxDecoration(
        color: AppColors.surface2,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.white10),
      ),
      alignment: Alignment.center,
      child: const Text(
        'Banner reklam alanı',
        style: TextStyle(color: AppColors.textDim, fontSize: 12),
      ),
    );
  }
}

import 'dart:math';

import '../models.dart';

/// Instagram ile konuşan katman.
///
/// ÖNEMLİ: Instagram'ın resmi API'si (Graph API) takip listesi okuma,
/// takipten çıkarma, otomatik beğeni gibi işlemlere izin vermez.
/// Bu yüzden uygulama şimdilik [DemoInstagramService] ile çalışır.
/// Kendi sunucunuz / onaylı bir servis hazır olduğunda bu arayüzü
/// uygulayan yeni bir sınıf yazıp main.dart içinde değiştirmeniz yeterli.
abstract class InstagramService {
  Future<IgAccount> connect({String? username});
  Future<List<IgUser>> users();
  Future<DailyChange> todayChange(List<IgUser> users);
  Future<List<IgPost>> posts();
  Future<List<Engager>> engagers(List<IgUser> users);
  Future<void> unfollow(IgUser user);
  Future<void> deletePost(IgPost post);
  Future<void> likePost(IgUser user, int index);
}

class DemoInstagramService implements InstagramService {
  final _rnd = Random(42);
  List<IgUser>? _users;
  List<IgPost>? _posts;

  static const _first = [
    'ahmet', 'elif', 'mehmet', 'zeynep', 'can', 'ece', 'burak', 'selin',
    'emre', 'derya', 'mert', 'asli', 'kaan', 'ceren', 'onur', 'irem',
    'berk', 'gizem', 'cem', 'melis', 'arda', 'sude', 'yigit', 'naz',
  ];
  static const _last = [
    'yilmaz', 'kaya', 'demir', 'celik', 'sahin', 'aydin', 'ozturk',
    'arslan', 'dogan', 'kilic', 'aslan', 'cetin', 'koc', 'polat',
  ];

  String _cap(String s) => s[0].toUpperCase() + s.substring(1);

  @override
  Future<IgAccount> connect({String? username}) async {
    await Future.delayed(const Duration(milliseconds: 900));
    final u = (username == null || username.trim().isEmpty)
        ? 'demo_hesap'
        : username.trim().replaceAll('@', '');
    return IgAccount(username: u, name: _cap(u.split(RegExp(r'[._]')).first));
  }

  @override
  Future<List<IgUser>> users() async {
    await Future.delayed(const Duration(milliseconds: 500));
    return _users ??= List.generate(140, (i) {
      final f = _first[_rnd.nextInt(_first.length)];
      final l = _last[_rnd.nextInt(_last.length)];
      final username = i % 3 == 0 ? '$f.$l' : '${f}_$l$i';
      final follows = _rnd.nextDouble() < 0.72;
      final followedBy = _rnd.nextDouble() < 0.66;
      return IgUser(
        username: username,
        name: '${_cap(f)} ${_cap(l)}',
        hue: _rnd.nextInt(360),
        iFollow: follows || (!followedBy),
        followsMe: followedBy,
      );
    });
  }

  @override
  Future<DailyChange> todayChange(List<IgUser> users) async {
    final fans = users.where((u) => u.followsMe).toList()..shuffle(_rnd);
    final lost = users.where((u) => !u.followsMe).toList()..shuffle(_rnd);
    return DailyChange(
      gained: fans.take(7).toList(),
      lost: lost.take(4).toList(),
    );
  }

  @override
  Future<List<IgPost>> posts() async {
    await Future.delayed(const Duration(milliseconds: 300));
    if (_posts != null) return _posts!;
    const titles = [
      'Sahil günü 🌊', 'Yeni reels 🎬', 'Kahve molası ☕', 'Şehir turu 🏙️',
      'Antrenman 💪', 'Gün batımı 🌅', 'Mutfak denemesi 🍝', 'Hafta sonu 🎉',
    ];
    _posts = List.generate(titles.length, (i) {
      final video = i % 2 == 0;
      return IgPost(
        id: 'p$i',
        title: titles[i],
        isVideo: video,
        views: video ? 2000 + _rnd.nextInt(48000) : 800 + _rnd.nextInt(6000),
        likes: 80 + _rnd.nextInt(1800),
        comments: 3 + _rnd.nextInt(120),
      );
    });
    return _posts!;
  }

  @override
  Future<List<Engager>> engagers(List<IgUser> users) async {
    final pool = List<IgUser>.from(users)..shuffle(_rnd);
    final list = pool
        .take(14)
        .map((u) => Engager(
              user: u,
              likes: 1 + _rnd.nextInt(9),
              comments: _rnd.nextInt(5),
            ))
        .toList()
      ..sort((a, b) => b.score.compareTo(a.score));
    return list;
  }

  @override
  Future<void> unfollow(IgUser user) async {
    await Future.delayed(const Duration(milliseconds: 80));
    user.iFollow = false;
  }

  @override
  Future<void> deletePost(IgPost post) async {
    await Future.delayed(const Duration(milliseconds: 400));
    _posts?.removeWhere((p) => p.id == post.id);
  }

  @override
  Future<void> likePost(IgUser user, int index) async {
    await Future.delayed(const Duration(milliseconds: 80));
  }
}

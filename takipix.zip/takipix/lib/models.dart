class IgUser {
  IgUser({
    required this.username,
    required this.name,
    required this.hue,
    required this.iFollow,
    required this.followsMe,
  });

  final String username;
  final String name;
  final int hue;
  bool iFollow;
  bool followsMe;
}

class IgAccount {
  IgAccount({required this.username, required this.name});
  final String username;
  final String name;
}

class IgPost {
  IgPost({
    required this.id,
    required this.title,
    required this.isVideo,
    required this.views,
    required this.likes,
    required this.comments,
  });

  final String id;
  final String title;
  final bool isVideo;
  final int views;
  final int likes;
  final int comments;
}

class Engager {
  Engager({required this.user, required this.likes, required this.comments});
  final IgUser user;
  final int likes;
  final int comments;
  int get score => likes + comments * 3;
}

class DailyChange {
  DailyChange({required this.gained, required this.lost});
  final List<IgUser> gained;
  final List<IgUser> lost;
  int get net => gained.length - lost.length;
}

class AutoReplyRule {
  AutoReplyRule({
    required this.id,
    required this.keyword,
    required this.reply,
    this.enabled = true,
  });

  final String id;
  String keyword;
  String reply;
  bool enabled;

  Map<String, dynamic> toJson() => {
        'id': id,
        'keyword': keyword,
        'reply': reply,
        'enabled': enabled,
      };

  factory AutoReplyRule.fromJson(Map<String, dynamic> j) => AutoReplyRule(
        id: j['id'] as String,
        keyword: j['keyword'] as String,
        reply: j['reply'] as String,
        enabled: j['enabled'] as bool? ?? true,
      );
}

class ReplyLogEntry {
  ReplyLogEntry({
    required this.from,
    required this.message,
    required this.reply,
    required this.time,
  });
  final String from;
  final String message;
  final String reply;
  final DateTime time;
}

class PremiumPlan {
  const PremiumPlan({
    required this.id,
    required this.title,
    required this.price,
    required this.days,
    this.tag,
  });
  final String id;
  final String title;
  final String price;
  final int days;
  final String? tag;
}
